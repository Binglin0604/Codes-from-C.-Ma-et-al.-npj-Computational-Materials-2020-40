clear;clc
file = dir('*.txt');
n_sampling=25;
sampling(size(file,1),n_sampling)=0;
sampling(size(file,1),n_sampling)=0;
for i1=1:size(file,1)
   data=load(file(i1).name);
%    sampling(i1,:)=data(2:3:101,2);
   sampling(i1,:)=data(101:-4:2,2);
%    sampling(i1,:)=data(2:end,2);
end
sampling=fliplr(sampling);
save sampling_25pts_10mm
