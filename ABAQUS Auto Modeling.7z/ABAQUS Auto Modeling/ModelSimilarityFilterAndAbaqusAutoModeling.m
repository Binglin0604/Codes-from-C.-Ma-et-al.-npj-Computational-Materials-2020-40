% The variable "group" is a hierarchical cell, which contains all the
% combinations and grouping results based on geometric symmetry. The i-th
% row of the "group" is the result of "choose i from n", and each element
% of group{i,1} contains all the geometrically symmetric structures, and
% the group{i,1}(1,:) is the typical result.
% The variable "group_abaqus" is the final results for ABAQUS modeling.

clear;
n0=4; % #grids of one side
n=n0^2;

% preallocation
% num = numel(ceil(n/2):n);
num = n;
n_comb(num,1) = 0; 
comb_binary_cell{num,2} = 0;
group{num,3} = 0;

% calculate the combs and then group them

for i0 = ceil(n/2):n
    A = nchoosek(1:n,i0); %choose i0 out of n, N=size(A,1)
    B = zeros(size(A,1),n); % B = N x n
    C = B;
    B(:,1:size(A,2)) = A;
    n_comb(i0,1) = size(A,1);
    for i1 = 1:n_comb(i0,1)
        C(i1,A(i1,:)) = 1;
    end
    
    %judge the sym type for each line of C
    %                                      [Y] x-y symmetric (type5): only itsealf
    %                                     /
    %                 [Y] --(A==fliplr)--> 
    %                /                    \
    %               /                      [N] main diagonal symmetric (type1): flipud,fliplr,rot180
    %              /
    % A--(A==A')-->                        [Y] x-a xis symmetric (type2): flipud
    %              \                      /
    %               [N] --(A==flipud(A)-->                      [Y] y-axis symmetric (type3): fliplr                         
    %                                     \                    /
    %                                      [N] --(A==fliplr)-->
    %                                                          \
    %                                                           [N] non-symmetric + counter-diagonal symmetric (type4): flipud,fliplr,rot180
    C_search = C; % the dictionary
    group{i0,1} = cell(ceil(n_comb(i0,1)/2),1); % 
    num_group = 0;
    while size(C_search,1) > 0
%     for i1 = 1:n_comb(i0,1)
        C_test = reshape(C_search(1,:),n0,n0); 
        C_test_diag = C_test';
        num_group = num_group+1;
        if isequal(C_test,C_test_diag)
            C_test_y = fliplr(C_test);
            if isequal(C_test,C_test_y)
                idx_sym_type = 5; % xy sym
                group0 = C_search(1,:);
                C_search(1,:) = [];
            else
                idx_sym_type = 1; % diag sym
                C_test_x = flipud(C_test);
                C_test_180 = rot90(rot90(C_test));
                group0 = [C_search(1,:); reshape(C_test_x,1,[]); reshape(C_test_y,1,[]); reshape(C_test_180,1,[])];
                C_search(1,:) = [];
                for i2 = 2:4
                    C_search(sum(abs(C_search-group0(i2,:)),2)==0,:) = []; % delete the combs with the same type as C_test from C_search
                end
            end
        else
            C_test_x = flipud(C_test);
            if isequal(C_test,C_test_x)
                idx_sym_type = 2; % x sym Note that xy sym are included in x sym
                group0 = [C_search(1,:);reshape(fliplr(C_test),1,[])];
                C_search(1,:) = [];
                C_search(sum(abs(C_search-group0(2,:)),2)==0,:) = []; % delete the combs with the same type as C_test from C_search 
            else
                C_test_y = fliplr(C_test);
                if isequal(C_test,C_test_y)
                    idx_sym_type = 3; %y sym
                    group0 = [C_search(1,:);reshape(C_test_x,1,[])];
                    C_search(1,:) = [];
                    C_search(sum(abs(C_search-group0(2,:)),2)==0,:) = []; % delete the combs with the same type as C_test from C_search 
                else
                    idx_sym_type = 4; % non sym
                    group0 = [C_search(1,:); reshape(C_test_x,1,[]); reshape(C_test_y,1,[]); reshape(rot90(rot90(C_test)),1,[])];
                    C_search(1,:) = [];
                    for i2 = 2:4
                        C_search(sum(abs(C_search-group0(i2,:)),2)==0,:) = []; % delete the combs with the same type as C_test from C_search  
                    end
                end
            end
        end 
        group{i0,1}{num_group,1} = group0;
        group{i0,1}{num_group,2} = idx_sym_type;
        group0 = [];
        group{i0,1}(num_group+1:end,:) = [];
        group{i0,2} = i0; % #filled mesh
    end
%     idx_sym_type(i0,:)=[{idx_sym_type0}, {i0}];
    clear idx_sym_type0
end
group(1:ceil(n/2)-1,:)=[];

if mod(n,2) ~= 0 %odd num, inverse all the element
    group_inv = flipud(group);
    for i1 = 1:size(group_inv,1)
        for i2 = 1: size(group_inv{i1,1},1)
            group_inv{i1,1}{i2,1} = ~group_inv{i1,1}{i2,1};
        end
        group_inv{i1,2} = n-group_inv{i1,2}; % #filled mesh
    end
else %even num, inverse all the element except the first one
    group_inv = flipud(group(2:end,:));
    for i1 = 1:size(group_inv,1)
        for i2 = 1: size(group_inv{i1,1},1)
            group_inv{i1,1}{i2,1} = ~group_inv{i1,1}{i2,1};
        end
        group_inv{i1,2} = n-group_inv{i1,2}; % #filled mesh
    end
end
group = [group_inv;group];
for i1 = 1:size(group,1)
    group{i1,3} = size(group{i1,1},1);
end

% data for Abaqus
group_abaqus(sum(cell2mat(group(:,3))),n) = 0;
i3 = 1;
for i1 = 1:size(group,1)
    for i2 = 1: size(group{i1,1},1)
        group_abaqus(i3,:) = group{i1,1}{i2,1}(1,:);
        i3 = i3 + 1;
    end
end

 
% dim1 = reshape(group{5,1}{35,1},n0,n0);
% [x,y] = meshgrid(0:1:n0, 0:1:n0);
% mymap = [0 0 0; 1 1 1];
% figure;
% surface(x,y,dim1); 
% colormap(mymap); 
% view(2); axis equal; axis tight

% run abaqus
% The naming rule of all 3-by-3 model files follows the format of "#1_#2_#3_#4_#5_#6", where?
% #1 = total number of grids,?
% #2 = serial number of model,?
% #3 = number of filled grids,
% #4 = 0-1 representation of the top row of the model, 0=unfilled, 1=filled,
% #5 = 0-1 representation of the middle row of the model, 0=unfilled, 1=filled,
% #6 = 0-1 representation of the bottom row of the model, 0=unfilled, 1=filled.
name_cd_main = pwd;
% parfor i1 = 1:size(group_abaqus,1)
for i1 = 1:size(group_abaqus,1)
    num = i1;
    if num<10
        num0 = ['0000',num2str(num)];
    elseif num<100 && num>=10
        num0 = ['000',num2str(num)];
    elseif num<1000 && num>=100
        num0 = ['00',num2str(num)];
    elseif num<10000 && num>=1000
        num0 = ['0',num2str(num)];
    else
        num0 = num2str(num);
    end
    input = group_abaqus(i1,:);
    n_fill = sum(input);
    name_dir = ['M',num0,'_',num2str(n_fill),'_',...
                num2str(input(1)),num2str(input(2)),num2str(input(3)),num2str(input(4)),'_',...
                num2str(input(5)),num2str(input(6)),num2str(input(7)),num2str(input(8)),'_',...
                num2str(input(9)),num2str(input(10)),num2str(input(11)),num2str(input(12)),'_',...
                num2str(input(13)),num2str(input(14)),num2str(input(15)),num2str(input(16))];
    if ~exist([name_cd_main,'\',name_dir],'dir')
        mkdir([name_cd_main,'\',name_dir]); % make new folder
    end
    copyfile("M4_parfor.py",[name_cd_main,'\',name_dir])
    cd([name_cd_main,'\',name_dir])
%     name_cd_new = pwd; % get the name of the current folder
%     save('input.txt','input','-ascii') % save does not work in parfor
    parsave(input)
    system(['abaqus cae noGUI=M4_parfor.py'])
    data = textread('M4.txt');
    data(:,1) = data(:,1)*0.2; % from 100 to 20(mm)
    parsave_out(data,name_dir);
    copyfile([name_dir,'.txt'],name_cd_main)
%     system(['abaqus cae ','script','=M4_parfor.py']);
    %rename the files
%     eval(['!rename TS1.txt ',num2str(n),'_',num2str(i1),'_',num2str(n_fill),'_',num2str(input(1)),num2str(input(2)),num2str(input(3)),'_',num2str(input(4)),num2str(input(5)),num2str(input(6)),'_',num2str(input(7)),num2str(input(8)),num2str(input(9)),'.txt'])
%     eval(['!rename TS1.inp ',num2str(n),'_',num2str(i1),'_',num2str(n_fill),'_',num2str(input(1)),num2str(input(2)),num2str(input(3)),'_',num2str(input(4)),num2str(input(5)),num2str(input(6)),'_',num2str(input(7)),num2str(input(8)),num2str(input(9)),'.inp'])
%     eval(['!rename TS1.odb ',num2str(n),'_',num2str(i1),'_',num2str(n_fill),'_',num2str(input(1)),num2str(input(2)),num2str(input(3)),'_',num2str(input(4)),num2str(input(5)),num2str(input(6)),'_',num2str(input(7)),num2str(input(8)),num2str(input(9)),'.odb'])
%     eval(['!rename TS1.png ',num2str(n),'_',num2str(i1),'_',num2str(n_fill),'_',num2str(input(1)),num2str(input(2)),num2str(input(3)),'_',num2str(input(4)),num2str(input(5)),num2str(input(6)),'_',num2str(input(7)),num2str(input(8)),num2str(input(9)),'.png'])
%     eval(['!rename TS1.dat ',num2str(n),'_',num2str(i1),'_',num2str(n_fill),'_',num2str(input(1)),num2str(input(2)),num2str(input(3)),'_',num2str(input(4)),num2str(input(5)),num2str(input(6)),'_',num2str(input(7)),num2str(input(8)),num2str(input(9)),'.dat'])
%     eval(['!rename TS1.log ',num2str(n),'_',num2str(i1),'_',num2str(n_fill),'_',num2str(input(1)),num2str(input(2)),num2str(input(3)),'_',num2str(input(4)),num2str(input(5)),num2str(input(6)),'_',num2str(input(7)),num2str(input(8)),num2str(input(9)),'.log'])
%     i1
end

function []=parsave(input)
	save('input.txt','input','-ascii')
%     save('name_cd.txt','name_cd_new','-ascii')
end

function []=parsave_out(data,name_dir)
	save([name_dir,'.txt'],'data','-ascii')
end