# -*- coding: mbcs -*-
#
# Abaqus/CAE Release 6.14-1 replay file
# Internal Version: 2014_06_04-18.11.02 134264
# Run by ian on Tue Jan 08 15:14:26 2019
#

# from driverUtils import executeOnCaeGraphicsStartup
# executeOnCaeGraphicsStartup()
#: Executing "onCaeGraphicsStartup()" in the site directory ...
from abaqus import *
from abaqusConstants import *
# session.Viewport(name='Viewport: 1', origin=(0.0, 0.0), width=222.166656494141, 
    # height=131.570602416992)
# session.viewports['Viewport: 1'].makeCurrent()
# session.viewports['Viewport: 1'].maximize()
from caeModules import *
from driverUtils import executeOnCaeStartup
executeOnCaeStartup()
# session.viewports['Viewport: 1'].partDisplay.geometryOptions.setValues(
    # referenceRepresentation=ON)

import numpy, os, sys
from os import path   
direction = os.getcwd()
os.chdir(direction)
hang = numpy.loadtxt('input.txt')
hang = map(int,hang)
# hang = numpy.array([1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0])
hang1 = hang[0:4]
hang2 = hang[4:8]
hang3 = hang[8:12]
hang4 = hang[12:16]
	
s = mdb.models['Model-1'].ConstrainedSketch(name='__profile__', 
    sheetSize=100.0)
g, v, d, c = s.geometry, s.vertices, s.dimensions, s.constraints
s.setPrimaryObject(option=STANDALONE)
s.rectangle(point1=(0.0, 0.0), point2=(49.5, 49.5))
p = mdb.models['Model-1'].Part(name='Part-1', dimensionality=TWO_D_PLANAR, 
    type=DEFORMABLE_BODY)
p = mdb.models['Model-1'].parts['Part-1']
p.BaseShell(sketch=s)
s.unsetPrimaryObject()
p = mdb.models['Model-1'].parts['Part-1']
session.viewports['Viewport: 1'].setValues(displayedObject=p)
del mdb.models['Model-1'].sketches['__profile__']
a = mdb.models['Model-1'].rootAssembly
session.viewports['Viewport: 1'].setValues(displayedObject=a)
session.viewports['Viewport: 1'].assemblyDisplay.setValues(
    optimizationTasks=OFF, geometricRestrictions=OFF, stopConditions=OFF)
a = mdb.models['Model-1'].rootAssembly
a.DatumCsysByDefault(CARTESIAN)
p = mdb.models['Model-1'].parts['Part-1']
a.Instance(name='Part-1-1', part=p, dependent=ON)
a = mdb.models['Model-1'].rootAssembly
a.ReferencePoint(point=(24.75, -0.5, 0.0))
a = mdb.models['Model-1'].rootAssembly
s1 = a.instances['Part-1-1'].edges
side1Edges1 = s1.getSequenceFromMask(mask=('[#1 ]', ), )
a.Surface(side1Edges=side1Edges1, name='XIABIAN')
#: The surface 'XIABIAN' has been created (1 edge).
session.viewports['Viewport: 1'].assemblyDisplay.setValues(interactions=ON, 
    constraints=ON, connectors=ON, engineeringFeatures=ON)
a = mdb.models['Model-1'].rootAssembly
r1 = a.referencePoints
refPoints1=(r1[4], )
region1=regionToolset.Region(referencePoints=refPoints1)
a = mdb.models['Model-1'].rootAssembly
region2=a.surfaces['XIABIAN']
mdb.models['Model-1'].Coupling(name='XIAOU', controlPoint=region1, 
    surface=region2, influenceRadius=WHOLE_SURFACE, couplingType=KINEMATIC, 
    localCsys=None, u1=ON, u2=ON, ur3=ON)
a = mdb.models['Model-1'].rootAssembly
a.regenerate()
session.viewports['Viewport: 1'].setValues(displayedObject=a)
a = mdb.models['Model-1'].rootAssembly
a.ReferencePoint(point=(24.75, 50.0, 0.0))

a = mdb.models['Model-1'].rootAssembly
r1 = a.referencePoints
refPoints1=(r1[7], )
region1=a.Set(referencePoints=refPoints1, name='S1')
a = mdb.models['Model-1'].rootAssembly
s1 = a.instances['Part-1-1'].edges
side1Edges1 = s1.getSequenceFromMask(mask=('[#4 ]', ), )
region2=regionToolset.Region(side1Edges=side1Edges1)
mdb.models['Model-1'].Coupling(name='SHANGOU', controlPoint=region1, 
    surface=region2, influenceRadius=WHOLE_SURFACE, couplingType=KINEMATIC, 
    localCsys=None, u1=ON, u2=ON, ur3=ON)
session.viewports['Viewport: 1'].partDisplay.setValues(sectionAssignments=OFF, 
    engineeringFeatures=OFF)
session.viewports['Viewport: 1'].partDisplay.geometryOptions.setValues(
    referenceRepresentation=ON)


session.viewports['Viewport: 1'].assemblyDisplay.setValues(interactions=OFF, 
    constraints=OFF, connectors=OFF, engineeringFeatures=OFF, 
    adaptiveMeshConstraints=ON)
mdb.models['Model-1'].ExplicitDynamicsStep(name='Step-1', previous='Initial', 
    timePeriod=100.0, massScaling=((SEMI_AUTOMATIC, MODEL, AT_BEGINNING, 1.0, 
    0.0, None, 0, 0, 0.0, 0.0, 0, None), ), improvedDtMethod=ON)
session.viewports['Viewport: 1'].assemblyDisplay.setValues(step='Step-1')

session.viewports['Viewport: 1'].assemblyDisplay.setValues(interactions=ON, 
    constraints=ON, connectors=ON, engineeringFeatures=ON, 
    adaptiveMeshConstraints=OFF)
mdb.models['Model-1'].ContactProperty('IntProp-1')
mdb.models['Model-1'].interactionProperties['IntProp-1'].TangentialBehavior(
    formulation=FRICTIONLESS)
mdb.models['Model-1'].interactionProperties['IntProp-1'].NormalBehavior(
    pressureOverclosure=HARD, allowSeparation=ON, 
    constraintEnforcementMethod=DEFAULT)
mdb.models['Model-1'].interactionProperties['IntProp-1'].GeometricProperties(
    contactArea=22.0, padThickness=None)

session.viewports['Viewport: 1'].assemblyDisplay.setValues(step='Step-1')
p = mdb.models['Model-1'].parts['Part-1']
session.viewports['Viewport: 1'].setValues(displayedObject=p)
p = mdb.models['Model-1'].parts['Part-1']
s = p.features['Shell planar-1'].sketch
mdb.models['Model-1'].ConstrainedSketch(name='__edit__', objectToCopy=s)
s1 = mdb.models['Model-1'].sketches['__edit__']
g, v, d, c = s1.geometry, s1.vertices, s1.dimensions, s1.constraints
s1.setPrimaryObject(option=SUPERIMPOSE)
p.projectReferencesOntoSketch(sketch=s1, 
    upToFeature=p.features['Shell planar-1'], filter=COPLANAR_EDGES)

ZJ=1.5
KK=6
KG=6
#柱距 孔宽 孔高

# # import *.mat from MATLAB
# import scipy.io as sio
# hang = sio.loadmat(input.mat)

# import input.txt




# hang1=[1,0,1,1]
# hang2=[1,0,1,0]
# hang3=[1,1,1,0]
# hang4=[1,0,1,1]
# # number 7
# hang1=[1,1,0,1]
# hang2=[1,1,0,1]
# hang3=[1,0,1,1]
# hang4=[1,1,1,0]
# # number 7 flipud
# hang1=[1,1,1,0]
# hang2=[1,0,1,1]
# hang3=[1,1,0,1]
# hang4=[1,1,0,1]
# # numer 2
# hang1=[1,0,0,1]
# hang2=[1,1,0,0]
# hang3=[1,0,0,0]
# hang4=[1,0,0,0]

# hang1=[0,0,0,0]
# hang2=[0,0,0,0]
# hang3=[0,0,0,0]
# hang4=[0,0,0,0]

if hang4[0]==1:
 s1.rectangle(point1=(ZJ, ZJ), point2=(KK, KG))
 s1.rectangle(point1=(ZJ+KK, ZJ), point2=(2*KK, KG))
 s1.rectangle(point1=(ZJ, ZJ+KG), point2=(KK, 2*KG))
 s1.rectangle(point1=(ZJ+KK, ZJ+KG), point2=(2*KK, 2*KG))
else:
 s1.rectangle(point1=(ZJ, ZJ), point2=(2*KK, 2*KG))

if hang4[1]==1:
 s1.rectangle(point1=(ZJ+2*KK, ZJ), point2=(3*KK, KG))
 s1.rectangle(point1=(ZJ+3*KK, ZJ), point2=(4*KK, KG))
 s1.rectangle(point1=(ZJ+2*KK, ZJ+KG), point2=(3*KK, 2*KG))
 s1.rectangle(point1=(ZJ+3*KK, ZJ+KG), point2=(4*KK, 2*KG))
else:
 s1.rectangle(point1=(ZJ+2*KK, ZJ), point2=(4*KK, 2*KG))

if hang4[2]==1:
 s1.rectangle(point1=(ZJ+4*KK, ZJ), point2=(5*KK, KG))
 s1.rectangle(point1=(ZJ+5*KK, ZJ), point2=(6*KK, KG))
 s1.rectangle(point1=(ZJ+4*KK, ZJ+KG), point2=(5*KK, 2*KG))
 s1.rectangle(point1=(ZJ+5*KK, ZJ+KG), point2=(6*KK, 2*KG))
else:
 s1.rectangle(point1=(ZJ+4*KK, ZJ), point2=(6*KK, 2*KG))

if hang4[3]==1:
 s1.rectangle(point1=(ZJ+6*KK, ZJ), point2=(7*KK, KG))
 s1.rectangle(point1=(ZJ+7*KK, ZJ), point2=(8*KK, KG))
 s1.rectangle(point1=(ZJ+6*KK, ZJ+KG), point2=(7*KK, 2*KG))
 s1.rectangle(point1=(ZJ+7*KK, ZJ+KG), point2=(8*KK, 2*KG))
else:
 s1.rectangle(point1=(ZJ+6*KK, ZJ), point2=(8*KK, 2*KG))

if hang3[0]==1:
 s1.rectangle(point1=(ZJ, ZJ+2*KG), point2=(KK, 3*KG))
 s1.rectangle(point1=(ZJ+KK, ZJ+2*KG), point2=(2*KK, 3*KG))
 s1.rectangle(point1=(ZJ, ZJ+3*KG), point2=(KK, 4*KG))
 s1.rectangle(point1=(ZJ+KK, ZJ+3*KG), point2=(2*KK, 4*KG))
else:
 s1.rectangle(point1=(ZJ, ZJ+2*KG), point2=(2*KK, 4*KG))

if hang3[1]==1:
 s1.rectangle(point1=(ZJ+2*KK, ZJ+2*KG), point2=(3*KK, 3*KG))
 s1.rectangle(point1=(ZJ+3*KK, ZJ+2*KG), point2=(4*KK, 3*KG))
 s1.rectangle(point1=(ZJ+2*KK, ZJ+3*KG), point2=(3*KK, 4*KG))
 s1.rectangle(point1=(ZJ+3*KK, ZJ+3*KG), point2=(4*KK, 4*KG))
else:
 s1.rectangle(point1=(ZJ+2*KK, ZJ+2*KG), point2=(4*KK, 4*KG))

if hang3[2]==1:
 s1.rectangle(point1=(ZJ+4*KK, ZJ+2*KG), point2=(5*KK, 3*KG))
 s1.rectangle(point1=(ZJ+5*KK, ZJ+2*KG), point2=(6*KK, 3*KG))
 s1.rectangle(point1=(ZJ+4*KK, ZJ+3*KG), point2=(5*KK, 4*KG))
 s1.rectangle(point1=(ZJ+5*KK, ZJ+3*KG), point2=(6*KK, 4*KG))
else:
 s1.rectangle(point1=(ZJ+4*KK, ZJ+2*KG), point2=(6*KK, 4*KG))

if hang3[3]==1:
 s1.rectangle(point1=(ZJ+6*KK, ZJ+2*KG), point2=(7*KK, 3*KG))
 s1.rectangle(point1=(ZJ+7*KK, ZJ+2*KG), point2=(8*KK, 3*KG))
 s1.rectangle(point1=(ZJ+6*KK, ZJ+3*KG), point2=(7*KK, 4*KG))
 s1.rectangle(point1=(ZJ+7*KK, ZJ+3*KG), point2=(8*KK, 4*KG))
else:
 s1.rectangle(point1=(ZJ+6*KK, ZJ+2*KG), point2=(8*KK, 4*KG))


if hang2[0]==1:
 s1.rectangle(point1=(ZJ, ZJ+4*KG), point2=(KK, 5*KG))
 s1.rectangle(point1=(ZJ+KK, ZJ+4*KG), point2=(2*KK, 5*KG))
 s1.rectangle(point1=(ZJ, ZJ+5*KG), point2=(KK, 6*KG))
 s1.rectangle(point1=(ZJ+KK, ZJ+5*KG), point2=(2*KK, 6*KG))
else:
 s1.rectangle(point1=(ZJ, ZJ+4*KG), point2=(2*KK, 6*KG))

if hang2[1]==1:
 s1.rectangle(point1=(ZJ+2*KK, ZJ+4*KG), point2=(3*KK, 5*KG))
 s1.rectangle(point1=(ZJ+3*KK, ZJ+4*KG), point2=(4*KK, 5*KG))
 s1.rectangle(point1=(ZJ+2*KK, ZJ+5*KG), point2=(3*KK, 6*KG))
 s1.rectangle(point1=(ZJ+3*KK, ZJ+5*KG), point2=(4*KK, 6*KG))
else:
 s1.rectangle(point1=(ZJ+2*KK, ZJ+4*KG), point2=(4*KK, 6*KG))

if hang2[2]==1:
 s1.rectangle(point1=(ZJ+4*KK, ZJ+4*KG), point2=(5*KK, 5*KG))
 s1.rectangle(point1=(ZJ+5*KK, ZJ+4*KG), point2=(6*KK, 5*KG))
 s1.rectangle(point1=(ZJ+4*KK, ZJ+5*KG), point2=(5*KK, 6*KG))
 s1.rectangle(point1=(ZJ+5*KK, ZJ+5*KG), point2=(6*KK, 6*KG))
else:
 s1.rectangle(point1=(ZJ+4*KK, ZJ+4*KG), point2=(6*KK, 6*KG))

if hang2[3]==1:
 s1.rectangle(point1=(ZJ+6*KK, ZJ+4*KG), point2=(7*KK, 5*KG))
 s1.rectangle(point1=(ZJ+7*KK, ZJ+4*KG), point2=(8*KK, 5*KG))
 s1.rectangle(point1=(ZJ+6*KK, ZJ+5*KG), point2=(7*KK, 6*KG))
 s1.rectangle(point1=(ZJ+7*KK, ZJ+5*KG), point2=(8*KK, 6*KG))
else:
 s1.rectangle(point1=(ZJ+6*KK, ZJ+4*KG), point2=(8*KK, 6*KG))


if hang1[0]==1:
 s1.rectangle(point1=(ZJ, ZJ+6*KG), point2=(KK, 7*KG))
 s1.rectangle(point1=(ZJ+KK, ZJ+6*KG), point2=(2*KK, 7*KG))
 s1.rectangle(point1=(ZJ, ZJ+7*KG), point2=(KK, 8*KG))
 s1.rectangle(point1=(ZJ+KK, ZJ+7*KG), point2=(2*KK, 8*KG))
else:
 s1.rectangle(point1=(ZJ, ZJ+6*KG), point2=(2*KK, 8*KG))

if hang1[1]==1:
 s1.rectangle(point1=(ZJ+2*KK, ZJ+6*KG), point2=(3*KK, 7*KG))
 s1.rectangle(point1=(ZJ+3*KK, ZJ+6*KG), point2=(4*KK, 7*KG))
 s1.rectangle(point1=(ZJ+2*KK, ZJ+7*KG), point2=(3*KK, 8*KG))
 s1.rectangle(point1=(ZJ+3*KK, ZJ+7*KG), point2=(4*KK, 8*KG))
else:
 s1.rectangle(point1=(ZJ+2*KK, ZJ+6*KG), point2=(4*KK, 8*KG))

if hang1[2]==1:
 s1.rectangle(point1=(ZJ+4*KK, ZJ+6*KG), point2=(5*KK, 7*KG))
 s1.rectangle(point1=(ZJ+5*KK, ZJ+6*KG), point2=(6*KK, 7*KG))
 s1.rectangle(point1=(ZJ+4*KK, ZJ+7*KG), point2=(5*KK, 8*KG))
 s1.rectangle(point1=(ZJ+5*KK, ZJ+7*KG), point2=(6*KK, 8*KG))
else:
 s1.rectangle(point1=(ZJ+4*KK, ZJ+6*KG), point2=(6*KK, 8*KG))

if hang1[3]==1:
 s1.rectangle(point1=(ZJ+6*KK, ZJ+6*KG), point2=(7*KK, 7*KG))
 s1.rectangle(point1=(ZJ+7*KK, ZJ+6*KG), point2=(8*KK, 7*KG))
 s1.rectangle(point1=(ZJ+6*KK, ZJ+7*KG), point2=(7*KK, 8*KG))
 s1.rectangle(point1=(ZJ+7*KK, ZJ+7*KG), point2=(8*KK, 8*KG))
else:
 s1.rectangle(point1=(ZJ+6*KK, ZJ+6*KG), point2=(8*KK, 8*KG))


s1.unsetPrimaryObject()
p = mdb.models['Model-1'].parts['Part-1']
p.features['Shell planar-1'].setValues(sketch=s1)
del mdb.models['Model-1'].sketches['__edit__']
p = mdb.models['Model-1'].parts['Part-1']
p.regenerate()
a = mdb.models['Model-1'].rootAssembly
a.regenerate()
a = mdb.models['Model-1'].rootAssembly
session.viewports['Viewport: 1'].setValues(displayedObject=a)
#


#材料
mdb.models['Model-1'].Material(name='Material-1')
mdb.models['Model-1'].materials['Material-1'].Density(table=((0.00124, ), ))
mdb.models['Model-1'].materials['Material-1'].Elastic(table=((2114.6, 0.3), ))
mdb.models['Model-1'].materials['Material-1'].Damping(alpha=10.0)
mdb.models['Model-1'].materials['Material-1'].Plastic(table=((72.116, 0.0), (
    72.116, 0.15), (72.0, 0.2)))
p = mdb.models['Model-1'].parts['Part-1']
session.viewports['Viewport: 1'].setValues(displayedObject=p)
mdb.models['Model-1'].HomogeneousSolidSection(name='Section-1', 
    material='Material-1', thickness=22.0)
p = mdb.models['Model-1'].parts['Part-1']
f = p.faces
faces = f.findAt(((25.0, 25.0, 0.0), ))
region = regionToolset.Region(faces=faces)
p = mdb.models['Model-1'].parts['Part-1']
p.SectionAssignment(region=region, sectionName='Section-1', offset=0.0, 
    offsetType=MIDDLE_SURFACE, offsetField='', 
    thicknessAssignment=FROM_SECTION)

##荷载
mdb.models['Model-1'].TabularAmplitude(name='Amp-1', timeSpan=STEP, 
    smooth=SOLVER_DEFAULT, data=((0.0, 0.0), (100.0, 1.0)))

session.viewports['Viewport: 1'].assemblyDisplay.setValues(step='Initial')
a1 = mdb.models['Model-1'].rootAssembly
r1 = a1.referencePoints
refPoints1=(r1[4], )
region = regionToolset.Region(referencePoints=refPoints1)
mdb.models['Model-1'].DisplacementBC(name='BC-1', createStepName='Initial', 
    region=region, u1=SET, u2=SET, ur3=SET, amplitude=UNSET, 
    distributionType=UNIFORM, fieldName='', localCsys=None)
a1 = mdb.models['Model-1'].rootAssembly
r1 = a1.referencePoints
refPoints1=(r1[7], )
region = regionToolset.Region(referencePoints=refPoints1)
mdb.models['Model-1'].DisplacementBC(name='BC-2', createStepName='Initial', 
    region=region, u1=SET, u2=UNSET, ur3=SET, amplitude=UNSET, 
    distributionType=UNIFORM, fieldName='', localCsys=None)
session.viewports['Viewport: 1'].assemblyDisplay.setValues(step='Step-1')
a1 = mdb.models['Model-1'].rootAssembly
r1 = a1.referencePoints
refPoints1=(r1[7], )
region = regionToolset.Region(referencePoints=refPoints1)
mdb.models['Model-1'].DisplacementBC(name='BC-3', createStepName='Step-1', 
    region=region, u1=UNSET, u2=-20.0, ur3=UNSET, amplitude='Amp-1', fixed=OFF, 
    distributionType=UNIFORM, fieldName='', localCsys=None)

##网格
p = mdb.models['Model-1'].parts['Part-1']
p.seedPart(size=0.75, deviationFactor=0.1, minSizeFactor=0.1)
p = mdb.models['Model-1'].parts['Part-1']
f = p.faces
pickedRegions = f.getSequenceFromMask(mask=('[#1 ]', ), )
p.setMeshControls(regions=pickedRegions, algorithm=MEDIAL_AXIS)
p = mdb.models['Model-1'].parts['Part-1']
elemType1 = mesh.ElemType(elemCode=CPS4R, elemLibrary=EXPLICIT, 
    secondOrderAccuracy=OFF, hourglassControl=DEFAULT, 
    distortionControl=DEFAULT)
elemType2 = mesh.ElemType(elemCode=CPS3, elemLibrary=EXPLICIT)
p = mdb.models['Model-1'].parts['Part-1']
f = p.faces
faces = f.findAt(((25.0, 37.0, 0.0), ))
pickedRegions =(faces, )
p.setElementType(regions=pickedRegions, elemTypes=(elemType1, elemType2))
p.generateMesh()
##历史
cliCommand("""session.journalOptions.setValues(replayGeometry=COORDINATE, recoverGeometry=COORDINATE)""")

a2 = mdb.models['Model-1'].rootAssembly
r1 = a2.referencePoints
refPoints1=(r1[4], )
a2.Set(referencePoints=refPoints1, name='X1')
session.viewports['Viewport: 1'].setValues(displayedObject=a)
regionDef=mdb.models['Model-1'].rootAssembly.sets['X1']

regionDef=mdb.models['Model-1'].rootAssembly.sets['X1']
mdb.models['Model-1'].HistoryOutputRequest(name='H-Output-2', 
    createStepName='Step-1', variables=('RF1', 'RF2',  
    ), region=regionDef, sectionPoints=DEFAULT, rebar=EXCLUDE)
mdb.models['Model-1'].historyOutputRequests['H-Output-2'].setValues(
    numIntervals=200)
	
a = mdb.models['Model-1'].rootAssembly		
session.viewports['Viewport: 1'].setValues(displayedObject=a)
# mdb.models['Model-1'].fieldOutputRequests['F-Output-1'].setValues(variables=(
    # 'RT',))
mdb.models['Model-1'].fieldOutputRequests['F-Output-1'].setValues(variables=(
    'S', 'MISES', 'PE', 'PEEQ', 'U', 'V', 'A', 'RF'))
mdb.models['Model-1'].fieldOutputRequests['F-Output-1'].setValues(
    numIntervals=20)
	
mdb.models['Model-1'].historyOutputRequests['H-Output-1'].setValues(variables=(
    'ALLIE', 'ALLKE'))
mdb.models['Model-1'].historyOutputRequests['H-Output-1'].setValues(
    numIntervals=100)
# del mdb.models['Model-1'].historyOutputRequests['H-Output-1']
# del mdb.models['Model-1'].fieldOutputRequests['F-Output-1']

lsj=0
for i in range(0,4):
    pdz=hang1[i]
    if pdz==1:
       lsj=lsj+1
       a3 = mdb.models['Model-1'].rootAssembly
       s1 = a3.instances['Part-1-1'].edges
       side1Edges1 = s1.findAt(((3+12*i, 43.5, 0.0), ), ((1.5+12*i, 45, 0.0), ), ((
           3+12*i, 48.0, 0.0), ), ((6.0+12*i, 45, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')
       lsj=lsj+1
       side1Edges1 = s1.findAt(((9+12*i, 43.5, 0.0), ), ((7.5+12*i, 45, 0.0), ), ((
           9+12*i, 48.0, 0.0), ), ((12.0+12*i, 45, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')
       lsj=lsj+1
       side1Edges1 = s1.findAt(((3+12*i, 37.5, 0.0), ), ((1.5+12*i, 39, 0.0), ), ((
           3+12*i, 42.0, 0.0), ), ((6+12*i, 39, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')
       lsj=lsj+1
       side1Edges1 = s1.findAt(((9+12*i, 37.5, 0.0), ), ((7.5+12*i, 39, 0.0), ), ((
           9+12*i, 42.0, 0.0), ), ((12+12*i, 39, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')
    else:
       lsj=lsj+1
       a3 = mdb.models['Model-1'].rootAssembly
       s1 = a3.instances['Part-1-1'].edges
       side1Edges1 = s1.findAt(((3+12*i, 37.5, 0.0), ), ((1.5+12*i, 45, 0.0), ), ((
           3+12*i, 48.0, 0.0), ), ((12.0+12*i, 45, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')
 
for i in range(0,4):
    pdz=hang2[i]
    if pdz==1:
       lsj=lsj+1
       a3 = mdb.models['Model-1'].rootAssembly
       s1 = a3.instances['Part-1-1'].edges
       side1Edges1 = s1.findAt(((3+12*i, 31.5, 0.0), ), ((1.5+12*i, 33, 0.0), ), ((
           3+12*i, 36, 0.0), ), ((6.0+12*i, 33, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')
       lsj=lsj+1
       side1Edges1 = s1.findAt(((9+12*i, 31.5, 0.0), ), ((7.5+12*i, 33, 0.0), ), ((
           9+12*i, 36, 0.0), ), ((12.0+12*i, 33, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')
       lsj=lsj+1
       side1Edges1 = s1.findAt(((3+12*i, 25.5, 0.0), ), ((1.5+12*i, 27, 0.0), ), ((
           3+12*i, 30, 0.0), ), ((6+12*i, 27, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')
       lsj=lsj+1
       side1Edges1 = s1.findAt(((9+12*i, 25.5, 0.0), ), ((7.5+12*i, 27, 0.0), ), ((
           9+12*i, 30, 0.0), ), ((12+12*i, 27, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')
    else:
       lsj=lsj+1
       a3 = mdb.models['Model-1'].rootAssembly
       s1 = a3.instances['Part-1-1'].edges
       side1Edges1 = s1.findAt(((3+12*i, 25.5, 0.0), ), ((1.5+12*i, 33, 0.0), ), ((
           3+12*i, 36, 0.0), ), ((12.0+12*i, 33, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')

for i in range(0,4):
    pdz=hang3[i]
    if pdz==1:
       lsj=lsj+1
       a3 = mdb.models['Model-1'].rootAssembly
       s1 = a3.instances['Part-1-1'].edges
       side1Edges1 = s1.findAt(((3+12*i, 19.5, 0.0), ), ((1.5+12*i, 21, 0.0), ), ((
           3+12*i, 24, 0.0), ), ((6.0+12*i, 21, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')
       lsj=lsj+1
       side1Edges1 = s1.findAt(((9+12*i, 19.5, 0.0), ), ((7.5+12*i, 21, 0.0), ), ((
           9+12*i, 24, 0.0), ), ((12.0+12*i, 21, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')
       lsj=lsj+1
       side1Edges1 = s1.findAt(((3+12*i, 13.5, 0.0), ), ((1.5+12*i, 15, 0.0), ), ((
           3+12*i, 18, 0.0), ), ((6+12*i, 15, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')
       lsj=lsj+1
       side1Edges1 = s1.findAt(((9+12*i, 13.5, 0.0), ), ((7.5+12*i, 15, 0.0), ), ((
           9+12*i, 18, 0.0), ), ((12+12*i, 15, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')
    else:
       lsj=lsj+1
       a3 = mdb.models['Model-1'].rootAssembly
       s1 = a3.instances['Part-1-1'].edges
       side1Edges1 = s1.findAt(((3+12*i, 13.5, 0.0), ), ((1.5+12*i, 21, 0.0), ), ((
           3+12*i, 24, 0.0), ), ((12.0+12*i, 21, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')

for i in range(0,4):
    pdz=hang4[i]
    if pdz==1:
       lsj=lsj+1
       a3 = mdb.models['Model-1'].rootAssembly
       s1 = a3.instances['Part-1-1'].edges
       side1Edges1 = s1.findAt(((3+12*i, 7.5, 0.0), ), ((1.5+12*i, 9, 0.0), ), ((
           3+12*i, 12, 0.0), ), ((6.0+12*i, 9, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')
       lsj=lsj+1
       side1Edges1 = s1.findAt(((9+12*i, 7.5, 0.0), ), ((7.5+12*i, 9, 0.0), ), ((
           9+12*i, 12, 0.0), ), ((12.0+12*i, 9, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')
       lsj=lsj+1
       side1Edges1 = s1.findAt(((3+12*i, 1.5, 0.0), ), ((1.5+12*i, 3, 0.0), ), ((
           3+12*i, 6, 0.0), ), ((6+12*i, 3, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')
       lsj=lsj+1
       side1Edges1 = s1.findAt(((9+12*i, 1.5, 0.0), ), ((7.5+12*i, 3, 0.0), ), ((
           9+12*i, 6, 0.0), ), ((12+12*i, 3, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')
    else:
       lsj=lsj+1
       a3 = mdb.models['Model-1'].rootAssembly
       s1 = a3.instances['Part-1-1'].edges
       side1Edges1 = s1.findAt(((3+12*i, 1.5, 0.0), ), ((1.5+12*i, 9, 0.0), ), ((
           3+12*i, 12, 0.0), ), ((12.0+12*i, 9, 0.0), ))
       region=regionToolset.Region(side1Edges=side1Edges1)
       mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
           surface=region, mechanicalConstraint=KINEMATIC, 
           interactionProperty='IntProp-1')

lsj=lsj+1
a = mdb.models['Model-1'].rootAssembly
s1 = a.instances['Part-1-1'].edges
side1Edges1 = s1.findAt(((49.5, 37.125, 0.0), ))
region=regionToolset.Region(side1Edges=side1Edges1)
mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
    surface=region, mechanicalConstraint=KINEMATIC, 
    interactionProperty='IntProp-1')
lsj=lsj+1
a = mdb.models['Model-1'].rootAssembly
s1 = a.instances['Part-1-1'].edges
side1Edges1 = s1.findAt(((0.0, 12.375, 0.0), ))
region=regionToolset.Region(side1Edges=side1Edges1)
mdb.models['Model-1'].SelfContactExp(name='Int-'+str(lsj), createStepName='Step-1', 
    surface=region, mechanicalConstraint=KINEMATIC, 
    interactionProperty='IntProp-1')

		   
#任务
mdb.Job(name='M4', model='Model-1', description='', type=ANALYSIS, 
    atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90, 
    memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, 
    explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
    modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', 
    scratch='', resultsFormat=ODB, multiprocessingMode=DEFAULT, numCpus=1,
    numDomains=1, numGPUs=0,activateLoadBalancing=0)
# mdb.jobs['M4'].setValues(numDomains=8, activateLoadBalancing=1, numCpus=2)
mdb.jobs['M4'].submit(consistencyChecking=OFF)
###数据
mdb.jobs['M4'].waitForCompletion()

# o3 = session.openOdb(name='E:/ABAQUS_temp/M4.odb')
o3 = session.openOdb(name='M4.odb')
session.viewports['Viewport: 1'].setValues(displayedObject=o3)
# odb = session.odbs['E:/ABAQUS_temp/M4.odb']
odb = session.odbs['M4.odb']
xy1 = xyPlot.XYDataFromHistory(odb=odb, 
    outputVariableName='Reaction force: RF2 PI: rootAssembly Node 1 in NSET X1', 
    steps=('Step-1', ), suppressQuery=True, __linkedVpName__='Viewport: 1')
# c1 = session.Curve(xyData=xy1)
# xyp = session.XYPlot('XYPlot-1')
# chartName = xyp.charts.keys()[0]
# chart = xyp.charts[chartName]
# chart.setValues(curvesToPlot=(c1, ), )
# session.viewports['Viewport: 1'].setValues(displayedObject=xyp)

#ratio of kinetic energy in internal energy
# odb = session.odbs['E:/ABAQUS_temp/M4.odb']
odb = session.odbs['M4.odb']
session.XYDataFromHistory(name='ALLKE Whole Model-1', odb=odb, 
    outputVariableName='Kinetic energy: ALLKE for Whole Model', 
    __linkedVpName__='Viewport: 1')
# odb = session.odbs['E:/ABAQUS_temp/M4.odb']
odb = session.odbs['M4.odb']
session.XYDataFromHistory(name='ALLIE Whole Model-1', odb=odb, 
    outputVariableName='Internal energy: ALLIE for Whole Model', 
    __linkedVpName__='Viewport: 1')
xy2 = session.xyDataObjects['ALLKE Whole Model-1']
xy3 = session.xyDataObjects['ALLIE Whole Model-1']
xy4 = xy2/xy3

## #输出txt
# numpy.savetxt(r'D:\Box Sync\box\01-3 Machine-Learning based Architected Material Design\03 Numerical Modeling\explicit4x4\M4.txt',xy1)
numpy.savetxt('M4.txt',xy1)
# numpy.savetxt(r'D:\Box Sync\box\01-3 Machine-Learning based Architected Material Design\03 Numerical Modeling\explicit4x4\M4-energy.txt',xy4)



#
###图片
##a = mdb.models['Model-1'].rootAssembly
##session.viewports['Viewport: 1'].setValues(displayedObject=a)
##session.viewports['Viewport: 1'].assemblyDisplay.setValues(
##    adaptiveMeshConstraints=OFF)
##o3 = session.openOdb(name='C:/Box Sync/Box Sync/ABAQUS_Auto_Modeling/TS1.odb')
##session.viewports['Viewport: 1'].setValues(displayedObject=o3)
##session.viewports['Viewport: 1'].odbDisplay.display.setValues(plotState=(
##    CONTOURS_ON_DEF, ))
##session.viewports['Viewport: 1'].viewportAnnotationOptions.setValues(title=OFF)
##session.viewports['Viewport: 1'].view.fitView()
##session.printToFile(fileName='C:/Box Sync/Box Sync/ABAQUS_Auto_Modeling/TS1', format=PNG, canvasObjects=(
##    session.viewports['Viewport: 1'], ))  # save location
## #视频
## a = mdb.models['Model-1'].rootAssembly
## session.viewports['Viewport: 1'].setValues(displayedObject=a)
## o3 = session.openOdb(name='F:/AB-CAL/TS1.odb')
## session.viewports['Viewport: 1'].setValues(displayedObject=o3)
## session.animationController.setValues(animationType=TIME_HISTORY, viewports=(
##     'Viewport: 1', ))
## session.animationController.play(duration=UNLIMITED)
## session.aviOptions.setValues(sizeDefinition=USER_DEFINED, imageSize=(2500,
##     1502), codecOptions='[12]:aaaaaaaaaiaaaaaaaaaaaaaa')
## session.imageAnimationOptions.setValues(vpDecorations=ON, vpBackground=OFF,
##     compass=OFF, timeScale=1, frameRate=8)
## session.writeImageAnimation(fileName='F:/AB-CAL/TSP1', format=AVI,
##     canvasObjects=(session.viewports['Viewport: 1'], ))
##
##Mdb()
##session.viewports['Viewport: 1'].setValues(displayedObject=None)