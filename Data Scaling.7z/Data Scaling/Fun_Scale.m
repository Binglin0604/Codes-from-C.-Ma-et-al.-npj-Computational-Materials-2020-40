
% Scale x between lb and ub;

function y=Fun_Scale(x,lb,ub)
a=ones(size(x,1),1)*min(x);
b=ones(size(x,1),1)*max(x);
y=((x-a)./(b-a))*(ub-lb)+lb;

end
